novosibirsk_questions = [
    {"question": "Какой это район?", "image": "images/image1.jpg", "answer": "Кировский"},
    {"question": "Какой это колледж?", "image": "images/image2.jpg", "answer": "НАТК"},
    {"question": "Какой это колледж?", "image": "images/image3.jpg", "answer": "НКЭиВТ"},
    {"question": "Что это за ВУЗ?", "image": "images/image4.jpg", "answer": "НГУАДИ"},
    {"question": "Какой это район?", "image": "images/image5.jpg", "answer": "Первомайский"},
    {"question": "А это какой район?", "image": "images/image6.jpg", "answer": "Октябрьский"},
    {"question": "Самое длинный путь метро?", "image": "images/image7.jpg", "answer": "Речной вокзал"},
    {"question": "Название красной ветки метро?", "image": "images/image8.jpg", "answer": "Ленинская"},
    {"question": "Название зеленой ветки метро?", "image": "images/image8.jpg", "answer": "Дзержинская"},
    {"question": "Есть ли у нас Китайские машины?", "image": "images/image10.jpeg", "answer": "Да"},
]